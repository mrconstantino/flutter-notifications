package br.com.alura.meetups

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
